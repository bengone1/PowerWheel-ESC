#define SCANTIME 10 // number of miliseconds between scans.

/*************************************
 * Arduino Nano
 * Pin definitions for the I/O to the rest of the system
 * Analog throttle must have the analog input name instead of pin number
 *****************************************/

#define IN_THROTTLE A0    // Analog input number here (ex, A0, not 18)
 
#define IN_SPEED_LOW 3
#define IN_SPEED_HIGH 2
#define IN_SPEED_REV 4
#define IN_BRAKE 12
#define OUT_LPWM 5
#define OUT_RPWM 6
#define OUT_LEN 8
#define OUT_REN 7

/*
 * Define the following values to match the wiring.
 * These allow for PNP or NPN wiring and the in and out to differ.
 */

#define IN_ON 0
#define IN_OFF 1
#define OUT_ON 1
#define OUT_OFF 0

/*
 * Throttle switch off/max values
 * For smoother operation, set these to values slightly above the off value seen 
 * and slightly below the maximum value seen to make a 'dead zone' at the 
 * top and bottom of the pedal.
 */
 
#define THROTTLE_OFF_VAL 240   // Minimum voltage seen with pedal at full release.  Use DEBUG 1 to see output
#define THROTTLE_MAX_VAL 765   // Max voltage seen at full depression. Use DEBUG 1 to see output

/*
 * Speed range definitions below
 */

#define SPEED_MINIMUM 80      // Minimum duty cycle output.  This should be slightly higher than the lowest output that moves the Powerwheel with the kid in it.
#define SPEED_LOW_MAX 140     // Maximum duty cycle in Low Speed
#define SPEED_HIGH_MAX 180    // Maximum duty cycle in High Speed
#define SPEED_REV_MAX 100     // Maximum duty cycle in Reverse
#define ACCEL_STEP 7          // Defines the acceleration steps.  Adjust this if acceleration is sluggish. Lower is slower
#define DECEL_STEP 10         // Defines the acceleration steps.  Adjust this if deceleration is abrupt. Lower is slower

/*
 * STEPTIME defines the time in milliseconds between steps.  This can also be used to change the acceleration's granularity.
 */

#define STEPTIME 100 
